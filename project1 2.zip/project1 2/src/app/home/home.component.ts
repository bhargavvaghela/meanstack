import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { } from '@fortawesome/free-solid-svg-icons';
import { faLinkedin} from '@fortawesome/free-brands-svg-icons';

import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LearnMoreModalComponent } from '../learn-more-modal/learn-more-modal.component';
  import { from } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public linkedin = faLinkedin;

  constructor(private router: Router,private modalService: NgbModal) { }

  ngOnInit(): void {
    // if (!sessionStorage.getItem('sid')) {
    //   this.router.navigate(['login']);
    // }
  }
  loginProcess(){
    this.router.navigate(['login']);
  }

  processLearn() {
    this.modalService.open(LearnMoreModalComponent, {
      centered: true,
    }); 
  }

  RegProcess(){
    this.router.navigate(['register']);
  }
}
