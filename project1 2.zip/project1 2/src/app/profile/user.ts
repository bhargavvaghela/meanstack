export class User {
    public username:string;
    public firstName:string;
    public lastName:string;
    public password:string;
    public email:string;
    public mobile:number;
    public city:string;
    public university:string;
    public about:string;
    public skills:string;

    


}
