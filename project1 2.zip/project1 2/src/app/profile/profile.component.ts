import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ActivatedRouteSnapshot } from '@angular/router';

import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LogoutModalComponent } from '../logout-modal/logout-modal.component';
import{ DeleteProfileComponent } from '../delete-profile/delete-profile.component'
import { FormBuilder, Validators } from '@angular/forms';

import { HttpClient } from '@angular/common/http';
import { User} from './user'
import { from } from 'rxjs';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
  
})
export class ProfileComponent implements OnInit {
  public username:string;
  public users:User;

  constructor(private router : Router,
    private modalService: NgbModal,
    private route : ActivatedRoute,
    private fb: FormBuilder,
    private http: HttpClient

    ) { 
    this.username = this.route.snapshot.paramMap.get('username');
  
      this.loginProcessHere();
      this.users = new User();

   

    }

  ngOnInit(): void {
    if (!sessionStorage.getItem('sid')) {
      this.router.navigate(['login']);
    }
  }

  processLogout() {
    this.modalService.open(LogoutModalComponent, {
      centered: true,
    }); 
  }

  public async deleteUser(){
    
    const url = 'http://localhost:3003/deleteUser';
    const result: any = await this.http.post(url,{username:this.username}).toPromise();

    if(result){
      this.modalService.open(DeleteProfileComponent,{
        centered:true
      })
    }
   
    
  }

  public async loginProcessHere() {

      const url = 'http://localhost:3003/profile';
      const result: any = await this.http.post(url,{username:this.username}).toPromise();
      console.log(result[0]);
      this.users = result[0] as User;
  }


}


