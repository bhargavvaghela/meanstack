import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProfileComponent } from './profile/profile.component';
import {ForgotPasswordComponent} from './forgot-password/forgot-password.component';
import{ LogoutModalComponent } from './logout-modal/logout-modal.component';
import { LearnMoreModalComponent } from './learn-more-modal/learn-more-modal.component';
import { DeleteProfileComponent } from './delete-profile/delete-profile.component';
import { ForgotPassModalComponent } from './forgot-pass-modal/forgot-pass-modal.component';
import { RegisterModalComponent } from './register-modal/register-modal.component';

const routes: Routes = [{path: 'login', component : LoginComponent}, 
{path: 'register', component : RegisterComponent},
{path: 'home', component : HomeComponent},
{path: 'profile/:username',component: ProfileComponent},
{path: 'forgot-password',component: ForgotPasswordComponent},
{path: 'logout-modal',component:LogoutModalComponent},
{path: 'learn-more-modal',component:LearnMoreModalComponent},
{path: 'delete-profile',component:DeleteProfileComponent},
{path:'forgot-pass-modal',component:ForgotPassModalComponent},
{path:'register-modal',component:RegisterModalComponent},
{ path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
