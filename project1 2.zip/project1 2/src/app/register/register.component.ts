import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ForgotPassModalComponent } from '../forgot-pass-modal/forgot-pass-modal.component';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RegisterModalComponent } from '../register-modal/register-modal.component';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {

  public uiInvalidCredential = false;

  public fbFormGroup = this.fb.group({
    username:['',[Validators.required,Validators.pattern("^[a-z0-9A-Z]{3,15}")]],
    firstname: ['', [Validators.required,Validators.pattern("^[a-zA-Z]{3,15}")]],
    lastname: ['', [Validators.required,Validators.pattern("^[a-zA-Z]{3,15}")]],
    password:['',[Validators.required,Validators.pattern("[A-Za-z0-9*]{5,15}")]],
    email:['',[Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
    mobile:['',[Validators.required,Validators.maxLength(10),Validators.pattern('^[0-9]{10}')]],
    city: ['', [Validators.required,Validators.pattern("^[a-zA-Z]{3,15}")]],
    university: ['', [Validators.required,Validators.pattern("[A-Za-z, ]{5,30}")]],
    about: ['', Validators.required],
    skills: ['', [Validators.required,Validators.pattern("[A-Za-z, ]{3,50}")]]
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {}

  async registerHere() {
    const data = this.fbFormGroup.value;
    const url = 'http://localhost:3003/adduser';

    await this.http.post(url, data).toPromise();
    this.modalService.open(RegisterModalComponent,{
      centered:true
    })
    
  }

  
}