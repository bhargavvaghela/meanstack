import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-profile',
  templateUrl: './delete-profile.component.html',
  styleUrls: ['./delete-profile.component.css']
})
export class DeleteProfileComponent implements OnInit {

  constructor(public activeModal: NgbActiveModal,private router: Router) { }

  ngOnInit(): void {
  }

  closeTheModal() {
    this.activeModal.dismiss();

    sessionStorage.removeItem('sid');
    this.router.navigate(['login']);
  }


  

}
