import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'app-learn-more-modal',
  templateUrl: './learn-more-modal.component.html',
  styleUrls: ['./learn-more-modal.component.css']
})
export class LearnMoreModalComponent implements OnInit {

  constructor(public activeModal: NgbActiveModal) { }

  closeTheModal() {
    this.activeModal.dismiss();
  }

  ngOnInit(): void {
  }

}
