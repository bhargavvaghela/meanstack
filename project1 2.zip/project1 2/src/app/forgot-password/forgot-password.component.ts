import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ForgotPassModalComponent } from '../forgot-pass-modal/forgot-pass-modal.component';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  public uiInvalidCredential = false;
  
  public fbFormGroup = this.fb.group({
  
    email: ['', Validators.required],
    password: ['',Validators.required]
    
  });
  constructor( private fb: FormBuilder,
    private modalService: NgbModal,
    private router: Router,
    private http: HttpClient) { }

  ngOnInit(): void {
  }

  async changePass() {
    const data = this.fbFormGroup.value;
    const url = 'http://localhost:3003/changePass';
    

    const results = await this.http.post(url, data).toPromise();
    this.modalService.open(ForgotPassModalComponent,{
      centered:true
    })
    
  }

 
}
