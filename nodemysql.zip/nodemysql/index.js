const express = require("express");
const cors = require("cors");
const multer = require("multer");

const app = express();


app.use(cors()); 
app.use(express.json()); 
app.use(express.urlencoded({ extended: true }));
const upload = multer(); 

const dbadduser = require("./main");


app.get("/a", (req, res) => {
  res.json({ title: "Welcome!!" });
});


app.post("/adduser", async (req, res) => {
  try {
    
    const input = req.body;

    await dbadduser.addUser(input);
    res.json({ message: "success" });
  } catch (err) {
    console.log(err);
    res.json({ message: "failure" });
  }
});


app.post("/auth-user", async (req, res) => {
  try {
    const input = req.body;

    await dbadduser.authenticateUser(input);
    res.json({ opr: true });
  } catch (err) {
    console.log(err);
    res.json({ opr: false });
  }
});

app.post("/changePass", async (req, res) => {
  try {
    
    const input = req.body;

    await dbadduser.changePass(input);
    res.json({ message: "success" });
  } catch (err) {
    console.log(err);
    res.json({ message: "failure" });
  }
});

app.post("/profile", async (req, res) => {
  try {
    
    const input = req.body;

    const results =  await dbadduser.profileUser(input);
    console.log(results);
    res.send(results);
  } catch (err) {
    
    res.json({ message: "failure" });
  }
});




app.post("/deleteUser", async (req, res) => {
  try {
    
    const input = req.body;

    await dbadduser.deleteUser(input);
    res.json({ message: "success" });
  } catch (err) {
    console.log(err);
    res.json({ message: "failure" });
  }
});


app.listen(3003);