
const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_CONFIG = {
  host: "127.0.0.1",
  user: "root",
  password: "password",
  database: "bhargav",
};

const addUser = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);

  await connection.connectAsync();

  const sql =
    "INSERT INTO PERSONS (USERNAME,FIRSTNAME,LASTNAME, PASSWORD, EMAIL, MOBILE, CITY, UNIVERSITY, ABOUT, SKILLS) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  await connection.queryAsync(sql, [
    input.username,
    input.firstname,
    input.lastname,
    input.password,
    input.email,
    input.mobile,
    input.city,
    input.university,
    input.about,
    input.skills
  ]);

  await connection.endAsync();
};



let authenticateUser = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql = "SELECT * FROM PERSONS WHERE USERNAME=? AND PASSWORD=?";
  const results = await connection.queryAsync(sql, [
    input.username,
    input.password,
  ]);

  await connection.endAsync();

  if (results.length === 0) {
    throw new Error("Invalid Credentials");
  }
};

let changePass = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);

  await connection.connectAsync();

  const sql =
    "UPDATE PERSONS SET password = ? where email = ?";
  await connection.queryAsync(sql, [
    
    input.password,
    input.email,
    
  ]);

  await connection.endAsync();
};


let profileUser = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();
  
  let sql = "SELECT * FROM PERSONS WHERE USERNAME = ?";
  const results = await connection.queryAsync(sql, [
    input.username
  ]);
 // console.log(results);
  await connection.endAsync();

  if (results.length === 0) {
    throw new Error("Invalid Credentials");
  }
  return results;
};

let deleteUser = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);

  await connection.connectAsync();

  const sql =
    "DELETE FROM PERSONS WHERE USERNAME=?";
  await connection.queryAsync(sql, [
    
    input.username
    
  ]);

  await connection.endAsync();
};




module.exports = { addUser, authenticateUser, changePass , profileUser , deleteUser};